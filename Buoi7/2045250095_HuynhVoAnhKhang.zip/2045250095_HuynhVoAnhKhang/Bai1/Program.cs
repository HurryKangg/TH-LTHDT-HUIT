﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CongTy ds = new CongTy();
            ds.DocFile(@"..\..\congty.xml");
            ds.XuatDS();

            Console.WriteLine("Tổng số tiền: ", ds.TongTien());

            Console.WriteLine("Tiền tro gia: ", ds.TienTroGia());

            ds.XuatSoLuongMuaNhieu();
            ds.XuatDS();
        }
    }
}
