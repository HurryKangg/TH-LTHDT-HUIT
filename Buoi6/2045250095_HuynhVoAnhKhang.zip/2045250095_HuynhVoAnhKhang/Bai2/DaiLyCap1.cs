﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai2
{
    public class DaiLyCap1 : KhachHang
    {
        double thoiGianHopTac;
        int namHopTac;
        public DaiLyCap1(): base()
        {
            
        }

        public DaiLyCap1(string ma, string ten, int sl, double gia, double tg, int namht) : base(ma, ten, sl, gia)
        {
            this.thoiGianHopTac = tg;
            this.namHopTac = namht;
        }

        public override double ChietKhau()
        {
            double chietKhau = 0;
            chietKhau = 0.3 * gia;
            if (thoiGianHopTac > 3 && chietKhau <= 0.35)
                chietKhau = namHopTac * (chietKhau + 0.1);
            return chietKhau;
        }
        public override void Xuat()
        {
            base.Xuat();
            Console.WriteLine($"Thoi gian hop tac: {thoiGianHopTac}");
            Console.WriteLine($"Nam hop tac: {namHopTac}");
            Console.WriteLine($"Chiet khau: {ChietKhau():N0}");
            Console.WriteLine($"Thanh tien: {ThanhTien()}");
        }
    }
}
